import com.fasterxml.jackson.annotation.JsonProperty;


public class Root {

	  @JsonProperty("Response") 
	    public Response response;
}
