import com.fasterxml.jackson.annotation.JsonProperty;


public class Response {

	
	   @JsonProperty("@success") 
	    public String success;
	    @JsonProperty("Result") 
	    public Result result;
	    @JsonProperty("Messages") 
	    public Messages messages;
}
