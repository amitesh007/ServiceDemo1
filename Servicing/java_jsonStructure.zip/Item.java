import com.fasterxml.jackson.annotation.JsonProperty;


public class Item {

	
	  @JsonProperty("@attribute") 
	    public String attribute;
	    @JsonProperty("@valueType") 
	    public String valueType;
	    @JsonProperty("@value") 
	    public String value;
	    @JsonProperty("@label") 
	    public String label;
	    @JsonProperty("@mandatory") 
	    public String mandatory;
	    @JsonProperty("@readonly") 
	    public String readonly;
	    @JsonProperty("@valueCCY") 
	    public String valueCCY;
	    @JsonProperty("@linkClass") 
	    public String linkClass;
	    @JsonProperty("@linkId") 
	    public String linkId;
	    @JsonProperty("@linkTarget") 
	    public String linkTarget;
	    @JsonProperty("@valueList") 
	    public ValueList valueList;

}
