import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Group {

	
	  @JsonProperty("@name") 
	    public String name;
	    public List<Item> item;
}
