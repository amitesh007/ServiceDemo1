import com.fasterxml.jackson.annotation.JsonProperty;


public class Result {

	
	  @JsonProperty("LiqBusinessObjects") 
	    public LiqBusinessObjects liqBusinessObjects;
}
