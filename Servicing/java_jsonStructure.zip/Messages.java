import com.fasterxml.jackson.annotation.JsonProperty;

public class Messages {

	
	   @JsonProperty("Message") 
	    public String message;
}
