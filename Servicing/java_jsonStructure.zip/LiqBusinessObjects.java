import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LiqBusinessObjects {

	  @JsonProperty("@class") 
	    public String classi;
	    @JsonProperty("@ownerClass") 
	    public String ownerClass;
	    @JsonProperty("@ownerId") 
	    public String ownerId;
	    @JsonProperty("LiqBusinessObject") 
	    public List<LiqBusinessObject> liqBusinessObject;
}
