import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;


public class LiqBusinessObject {
	
	 @JsonProperty("@name") 
	    public String name;
	    @JsonProperty("@objectType") 
	    public String objectType;
	    @JsonProperty("@className") 
	    public String className;
	    @JsonProperty("@objectId") 
	    public String objectId;
	    public List<Group> group;

}
